% kpcabound(data,sigma,numev,outlier)
%
% kpcabound demonstrates 'Kernel PCA for novelty detection'
%
% kpcabound plots the reconstruction error in feature space into the 
% original space and plots the decision boundary enclosing all data points
% 
% input:
%
% data: array of data points, one row for each data point
% sigma: width of Gaussian kernel
% numev: number of eigenvalues to be extracted
% outlier: number of points outside the decision boundary
%
% (c) Heiko Hoffmann
%
% This code is distributed in the hope that it will be useful, but 
% without any warranty; even without the implied warranty of 
% merchantability or fitness for any purpose.


function kpcabound(data,sigma,numev,outlier)

     
 [n,d] = size(data);
 % n : number of data points
 % d : dimension of data points
 
 % kernel matrix:
 K = zeros(n,n);
 
 % kernel parameter:
 param = 0.5/(sigma*sigma);
 
 fprintf('computing kernel matrix K\n');
 for i=1:n 
   for j=i:n
     K(i,j) = kernel(data(i,:),data(j,:),param);
     K(j,i) = K(i,j);
   end
 end
 
 % correct K for non-zero center of data in feature space:
 Krow = sum(K,1)/n;
 Ksum = sum(Krow)/n;
 
 for i=1:n
   for j=1:n
     K(i,j) = K(i,j) - Krow(i) - Krow(j) + Ksum;
   end
 end
 
 fprintf('extracting eigenvectors of K\n');
 opts.disp = 0;
 [alpha,lambda]=eigs(K,numev,'lm',opts);
 
 % residual variance:
 resvar = (trace(K)-trace(lambda));
 fprintf('residual variance relative to total variance in feature space: %f %%\n',100*resvar/trace(K));
	 
 % normalize alpha:
 alpha = alpha * inv(sqrt(lambda));

 % compute some helper vectors:
 sumalpha = sum(alpha,1);
 alphaKrow = Krow * alpha;
 
 fprintf('evaluating reconstruction error for all data points\n');
 
 err = zeros(n,1);
 for i=1:n
   x = data(i,:); % test point
   err(i) = recerr(x,data,param,alpha,alphaKrow,sumalpha,Ksum);
 end
 
 serr = sort(err);
 maxerr = serr(n-outlier);
 
 fprintf('computing recontruction error over data space\n');
 xymin = min(data);
 xymax = max(data);
 range = xymax-xymin;
 
 offset = range*0.15; % provide some space around data points
 range = range*1.3;
 xymin = xymin-offset;
 xymax = xymax+offset;
 
 m = 100; % choose even value
 steps = (1.0-1e-6)*range/(m-1);
 [x1,x2] = meshgrid(xymin(1):steps(1):xymax(1),xymin(2):2*steps(2):xymax(2));
 err = zeros(m/2,m);
 
 for i=1:m/2
     for ii=1:m
         x = [x1(1,ii) x2(i,1)];       
         err(i,ii) = recerr(x,data,param,alpha,alphaKrow,sumalpha,Ksum);
     end
 end
 
 subplot(2,1,1), surf(x1,x2,err); view([-1 -7 14]); 
 xlabel('x'); ylabel('y'); zlabel('rec. err.');
 subplot(2,1,2), plot(data(:,1),data(:,2),'.k'); hold on;
 xlabel('x'); ylabel('y');
 contour(x1,x2,err,[maxerr maxerr],'r'); hold off;
 
   
  
	 
 
 
 
 
